package ui;

public enum Algorithm {
    BFS,UCS,A_STAR;
}
